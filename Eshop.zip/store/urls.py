from django.contrib import admin
from django.urls import path
from .views import home, login, signup, vsignup, vindex
from .views.login import Login, logout
from .views.vlogin import Vlogin, vlogout
from .views.home import Index, product
from .views.cart import Cart
from .views.product import UplaodProduct
from .views.vindex import Vproduct
from .views.checkout import CheckOut
from .views.review import RReview
from .views.orders import OrderView
from .middlewares.auth import auth_middleware

urlpatterns = [
    path('', Index.as_view(), name='homepage'),
    path('signup', signup.Signup.as_view(), name='signup'),
    path('vsignup', vsignup.Vsignup.as_view(), name='vsignup'),
    path('vindex', vindex.Vproduct.as_view(), name='vindex'),
    path('login', Login.as_view(), name='login'),
    path('vlogin', Vlogin.as_view(), name='vlogin'),
    path('vlogout', vlogout, name='vlogout'),
    path('product', UplaodProduct.as_view(), name='product'),
    # path('review', RReview.as_view(), name='review'),
    path('products/<int:myid>', product, name='product'),
    path('products/<int:myid>/review', RReview.as_view(), name='review'),
    path('logout', logout, name='logout'),
    path('cart', Cart.as_view(), name='cart'),
    path('check-out', CheckOut.as_view(), name='checkout'),
    path('orders', auth_middleware(OrderView.as_view()), name='orders')
]
