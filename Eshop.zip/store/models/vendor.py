from django.db import models

class Vendor(models.Model):
    name = models.CharField(max_length=50)
    shop_name = models.CharField(max_length=50)
    vphone = models.CharField(max_length=15)
    vemail = models.EmailField()
    vpassword = models.CharField(max_length=500)

    @staticmethod
    def get_vendor_by_email(vemail):
        try:
            return Vendor.objects.get(vemail=vemail)
        except:
            return False
    def vregister(self):
        self.save()
    def visExist(self):
        if Vendor.objects.filter(vemail=self.vemail):
            return True
        return False

    @staticmethod
    def get_all_vendors():
        return Vendor.objects.all()